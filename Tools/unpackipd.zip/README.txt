UnpackIPD v1.0.0.2
(C) 2014-2015 RAX Technologies
Portions (C) Microsoft Corporation
-------------------------------------------------

THIS PRODUCT IS NOT DEVELOPED, SUPPORTED, OR ENDORSED BY MICROSOFT CORPORATION!

Table of Contents
===========================
0. Disclaimer, Warranty, License
1. Introduction to SFXCAB
2. Basic Use
3. FAQ
4. Support and Misc.

0. Disclaimer, Warranty, License
==========================

Disclaimer/Warranty
--------------------
This software is provided 'as is'. It comes with absolutely no warranty, neither express or implied, on this software, nor are there any guarantees as to this software's merchantability or suitability for a particular purpose. While reasonable precautions have been taken, the author will not be held responsible should this software cause property damage, injury, or a loss of data, money, or time.

License
--------------------
UnpackIPD may be freely distributed, as long as you do not charge a fee of any kind for this software. All distributed copies of the program should include an unaltered copy of this README file. 

The software shall not be reverse engineered, disassembled, decompiled, or otherwise converted to human-readable code. In addition, the software shall not be altered in any way without permission from the authors. 

You are free to use this program as part of other software programs, provided that the following requirements
are met:

* The included copy of the software is unaltered.
* You do not misrepresent the origin of this software, or claim the software as your own development.

1. Introduction
==========================

UnpackIPD is a generic unpack utility for IPD Compression.

Intrapackage Delta compression, or IPD, is another compression method commonly used in SFXCAB archives to increase 
compression. If manually unpacked with a tool like 7-zip, an SFXCAB using IPD will contain a bunch of files named 
_sfx_XXXX._p, where XXXX is an incrementing number, an _sfx_.dll, and an _sfx_manifest_ file.

2. Basic Use
=========================

Run the utility. Specify the source and destination folders when prompted. They can also be specified on the command line: UnpackIPD.exe <source folder> <target folder>

A GUI version and command line version are included. The command line version requires the folders as arguments. The GUI will accept the folders as arguments, or prompt you if not specified.


3. FAQs
=================================

Q. My package won't unpack.
A. Make sure the _sfx_manifest_ and *._p files are in the folder you specify.

Q. I can't output to a UNC path.
A. Map a network drive.


4. Support and Misc.
=================================

Made because of an MSFN topic in March 2014 about unpacking an IPD archive. Happy Holidays 2014 from RAX Technologies! This program unpacks PATCHAPI IPD *only*! Compatible with official and SFXCAB Substitute IPD SFXCABs.

Questions or issues with this program or our other program SFXCAB substitute? 
Email the author at support@raxsoft.com

