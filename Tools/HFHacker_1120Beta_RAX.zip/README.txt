Hotfix Hacker
v1.1.0.20 Beta
Written by RAX Software
--------------------

This program is beta software. It is not guaranteed to work properly, may have bugs, and could cause your computer to stop responding or behave strangely.

It is published 'as-is', and comes with NO WARRANTY of any kind, neither express nor implied. The author makes no guarantee as to this software's merchantability or suitability for a particular purpose, and may not be held liable for any damages or losses, whether digital, physical, monetary, or otherwise. Please use at your own risk.

--------------------

Hotfix Hacker is a visual editor for creating and editing Windows Hotfix packages. You can decompile an existing package and examine it, or create a new hotfix from the ground up. The hotfixes built by it can be installed on Windows 2000 SP4, XP (all versions), and Server 2003.

--------------------

The below is a basic outline of how to use the program:

1. Open the program and choose File->New Hotfix
2. Fill out the "Update Information" section on the General Settings tab. If you want to include an EULA or digital signature, you can do so.
3. Go to the Files tab. Choose "Add" and select a file, specify its target name, directory, and flags. Repeat for each file you want to add.
4. If you need to add registry entries or catalogs, or run processes, use the appropriate tabs to add these tasks. Use is similar to the Files tab.
5. Choose File->Save and save the project (.hfp file).
6. Choose Hotfix->Compile Package and specify where you want the resulting update package saved.
7. Test the resulting EXE file. If needed, make changes and compile again.

--------------------

Custom Sections

--------------------

One feature of the program, custom sections, allows you to add your own file sections to the update.inf. The target directory for these sections is specified using standard INF DirIDs:

ID[,SubDirectory]

(The comma and subdirectory are optional)

Some common IDs are listed below. A full list can be found online. Search for "INF DirIDs".

-1 - Use value after the comma as an absolute path
10 - Windows directory
11 - System32 directory
12 - Drivers directory
17 - INF Directory
18 - Help directory
20 - Fonts directory
53 - User profile directory
16422 - Program Files directory
16427 - Program Files\Common Files directory

-------------------

WTRC Update 3.0

If using an installed version of this program, the installer may have installed RAX's digital signature certificates in your certificate stores. Because these certificates are not issued by a commercial Cerificate Authority, they must be added to the trusted certificate stores in order for digitally signed RAX files to be verified. These certificates occupy less than 50KB of hard drive space and pose no security risk.

If you want to remove these certificates for any reason, you may do so via Add/Remove Programs (Programs and Features on Windows Vista/7). The certificates are listed under RAX's former name, as "WOLS Technologies WTRC Update v3.0". Uninstall takes only seconds and does not require that you reboot your computer.

If the program you are using was distributed without an installer, these certificates may not be present on your system.

If these certificates are required by a RAX program, but are missing, you may receive errors saying that a file could not be verified, and the program may prompt you to download the certificates. The latest digital certificates for RAX software can be downloaded on the RAX website, http://www.raxsoft.tk

-------------------

Credits: 

* Several people for testing
* MSFN for the posts on patching update.exe and creating SFXCABs
* A personal friend of the developer, for figuring out intra-package delta compression, allowing development of the IPDTool used in this program.