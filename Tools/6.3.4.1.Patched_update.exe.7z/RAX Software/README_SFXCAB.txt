SFXCAB Substitute v9.1 (Stub v6.1.22.4)
(C) 2011 RAX Software
Portions (C) Microsoft Corporation
-------------------------------------------------

THIS PRODUCT IS NOT DEVELOPED, SUPPORTED, OR ENDORSED BY MICROSOFT CORPORATION!

This program is beta software. It is not guaranteed to work properly, may have bugs, and could cause your computer to stop responding or behave strangely.

Table of Contents
===========================
0. Disclaimer, Warranty, License
1. Introduction to SFXCAB
2. Basic Use
3. Intrapackage Delta Compression
   a. What is it?
   b. How it works
   c. Pros and Cons
   d. How SFXCAB Substitute packs IPD archives   
   e. File mating
   f. "File is corrupt" during unpack??

4. Advanced command line switches
5. Known bugs
6. FAQs and Troubleshooting
7. Credits

0. Disclaimer, Warranty, License
==========================

Disclaimer/Warranty
--------------------
This software is provided 'as is'. It comes with absolutely no warranty, neither express or implied, on this software, nor are there any guarantees as to this software's merchantability or suitability for a particular purpose. While reasonable precautions have been taken, the author will not be held responsible should this software cause property damage, injury, or a loss of data, money, or time.

License
--------------------
SFXCAB Substitute may be freely distributed, as long as you do not charge a fee of any kind for this 
software. All distributed copies of the program should include an unaltered copy of this README file. 

The software shall not be reverse engineered, disassembled, decompiled, or otherwise converted to human-readable code. In addition, the software shall not be altered in any way without permission from the authors. 

You are free to use this program as part of other software programs, provided that the following requirements
are met:

* The included copy of SFXCAB substitute is unaltered.
* The Disclaimer & License (section 0), and Credits (Section 7) contained in this readme appear in your 
  software's documentation.
* You do not misrepresent the origin of this software, or claim the software as your own development.

Some components of this software, including the SFXSTUB and IPD Engine are property of Microsoft Corporation. These tools are free software under Microsoft's license. The SFXSTUB (MSCF.sfx) can be freely obtained from any Windows XP Hotfix package. The IPD Engine (mspatchc.dll, mpatch.exe) and CABARC32 (cabarc32.exe) can be freely obtained from the Microsoft Windows SDK.

1. Introduction to SFXCAB
==========================

Most MS downloads, especially hotfixes and updates, are provided packaged in SFXCAB archives. 
An SFXCAB archive can be recognized by looking at its properties. SFXCAB files will usually 
explicitly mention SFXCAB in their version tab. These are packed using a special tool also 
called SFXCAB. This tool was not released to the public.

SFXCAB Substitute is a replacement for the unreleased SFXCAB.EXE used internally by Microsoft.
Its main purpose is to pack a folder of files to into a self-extracting SFXCAB archive. It can be used
to compress any folder of files, regardless of origin or creator.

2. Basic Use
=========================

It's recommended that the SFXCAB.exe file be placed in a folder in your PATH. C:\WINDOWS is the easiest location
to use.

The following is the layout of the SFXCAB command. Parameters in [ ] are optional. Options seperated by a |
are exclusive. You must choose ONE of options.

SFXCAB <OutputFile.exe> [-d:off|on|heavy] <source folder> [-r:[<folder>\file.exe]] [-ipd] [ipd switches]

If the source folder or output filename contains spaces, enclose it double quotes ("). Both absolute and relative
paths are supported for these two parameters. Wildcards are supported for the source folder. *.* is assumed if no wildcard is given.

   -d:off|on|heavy - Enables Debugging output. This is mainly for the developer's use. You shouldn't need to 
      use it unless the developer asks you to. "heavy" provides more output then "on". "off" is the default.
   
   -r:[<folder>\]file.exe - File to run after extract. Folder is optional, relative to the temporary folder where files 
      are extracted. NO ABSOLUTE PATHS. **Folder and filename are CASE SENSITIVE!**

   -ipd - Enables IPD compression. See section 3.

3. Intrapackage Delta Compression
==================================

a. What is it?
----------------------

Intrapackage Delta compression, or IPD, is another compression method commonly used in SFXCAB archives to increase 
compression. If manually unpacked with a tool like 7-zip, an SFXCAB using IPD will contain a bunch of files named 
_sfx_XXXX._p, where XXXX is an incrementing number, an _sfx_.dll, and an _sfx_manifest_ file.

b. How it works
----------------------

IPD compression works by storing only the differences in various files. If File A and File B are packed
together using IPD, File A will be stored, and the sections which are different in file B will be stored. Any identical 
data that appears in both files is only stored once, reducing size. 

The compression ratio depends upon how similar the files are to each other. If File A and file B are 100% identical,
file B is stored as a 1KB dummy, and File A is simply copied during the unpacking to create file B. Consequently, files
with absolutely no identical data will not compress well, or may even get larger.

SFXCAB Substitute supports using IPD on the packages it creates.

c. Pros and cons
----------------------

Pros: 
* IPD can increase compression on your packages, especially if many files are similar.
* It also provides a small amount of security, preventing users from manually unpacking 
  the archive without running it.

Cons:
* Applying IPD to some files can increase their size.
* Not all packages packed with IPD will unpack properly, due to technical limitations.
* Partial/corrupt archives cannot be recovered easily.

d. How SFXCAB Substitute packs an IPD archive
-----------------------

If IPD is enabled, SFXCAB will scan all files and choose "basis files". 4 files are chosen, one in each of 4 types (EXE files, DLLs, OCXs, SYS files).

All EXEs will be IPD'd against the basis EXE, unless file mating finds a better base. 
All DLLs will be IPD'd against the basis DLL, unless file mating finds a better base, and so on. 
Files with extensions other than EXE, DLL, SYS, OCX are IPD'd against the basis EXE.

After compressing the basis files, files are IPD'd as above. Files which were matched in file mating
are compressed first, followed by the remaining unmated files. A manifest containing unpacking information is 
then written to _sfx_manifest_

Once IPD has finished applying compression to the files, the manifest and IPD packed files are compiled into an 
SFXCAB archive. When run, the archive will extract the IPD'd data, then assemble the final files using the
manifest, before running the program specified at compile time (if specified).

e. File mating
-----------------------

When SFXCAB Substitute is applying IPD to files, file mating helps increase compression ratios. File mating
examines files, either by MD5 or by filename, and creates mated pairs of files that it thinks will increase
compression. These pairs will always contain at least 2 files, but may contain infinitely more.

When the files are compressed, the first file in a mated pair is IPD'd against the appropriate basis file.
Then, all remaining files in the mated pair are IPD'd against the first file.

The method used to create mated pairs can be selected by using the -matemode: parameter on the command line.
The default method is filenames, which gets very good compression with excellent speed.

f. "File is corrupt" during unpack??
-----------------------

Occasionally, a package with IPD compression may give a bogus "File is corrupt" while unpacking. This is a bug
in Microsoft's IPD engine, not a bug with SFXCAB Substitute. If this happens, try the following:

* Force SFXCAB to use a different basis EXE by using the -basisexe:<filename> parameter. 
* Try specifying the -iswu option, even if the package is not a Windows Update.
* Try specifying the smallest file (even if its not an EXE!) in your package as the basis EXE.
* Disable IPD

More often than not, a basis EXE that is too large causes this bogus error. Testing shows that basis EXEs over
about 350KB are more likely to cause errors.

4. Advanced Command line switches
==================================

SFXCAB substitute offers several advanced switches. Most switches deal with how SFXCAB works with IPD compression.

-iswu - Tells SFXCAB the files are a Windows Update package. This changes how certain files are handled, and reduces
        the likelihood that a "File is corrupt" will occur with these packages.

-basisexe:<filename> - Forces <filename> to be used as the Basis EXE. Try this first if an IPD package gives the bogus
                       "File is corrupt" explained in section 3f.

-basisdll:<filename> - Forces <filename> to be used as the Basis DLL.

-nocompress:file,file2,fileN... - Specifies a comma seperated list of files that IPD should not pack. These file will be
                                  be packed using standard compression only.

-matemode:name|md5|both|none - Specifies the method used for file mating. "name" will use filenames. "md5" will use MD5 
                               hashes, but slows compression significantly. "both" will have SFXCAB use both types of 
                               file mating. "none" disables file mating. DEFAULT is "name".

-s:nnnnnn - A debugging switch for the "-r:<file>" parameter. If the folder/file is correct (including the letter case!)
            specifying this with larger number will force SFXCAB to look further into the file before failing. 
            Value is in bytes from beginning of file. DEFAULT value is 2097152 (2MB).

-nosfx - Don't create an SFX file. Useful with -ipd if you want to use a different program to compress the IPD files.
         If used without -IPD, the program will have nothing to do.

-matedonly - Use IPD compression only on files that were matched in file mating. Other files will be excluded from IPD 
             and compressed only with standard Cab compression. If -matemode:none is specified along with this, 
             the package produced will be similar to one produced without IPD.

5. Known bugs
=================================

* File mating isn't perfect. It may accidentally leave one file out of a mated pair. This will not cause errors, but will
  cause less-than-optimum compression.
* IPD occasionally creates packages that won't unpack. Usually can be worked around by selecting the basis exe manually.
* File mating using MD5s may be excessively slow on some computers.
* UNC cannot be used for source/target.

6. FAQs
=================================

Q. SFXCAB hangs at "IPD: Computing MD5 hashes. This may take a while."?
A. This is normal. The MD5 functions are time consuming, especially if there are a lot of files to package. You can disable
   the MD5 file mating by removing the "-matemode:md5" or "-matemode:both" from the command line.

Q. SFXCAB fails to create the output file on a UNC path
A. UNC paths are not supported. Try mapping the path to a network drive.

Q. "File is corrupt" when unpacking an IPD compressed package
A. See section 3f for more information on this issue.

Q. SFXCAB takes forever when I specify the -ipd argument?
A. IPD is just a VERY slow compression process. When used on a large number of files, compression can take hours.
   If you're dealing with large numbers of files, regular compression is likely to be more effective, so disabling
   IPD is recommended.

Q. "ERROR: Nothing to do"
A. This happens because you've told SFXCAB substitute to not use CAB compression or IPD. Either add the -ipd command
   to produce a folder of IPD files, or remove the -nosfx command to enable creation of an SFX CAB archive.

Q. "Searching cabinet headers...not found" or similar message.
A. Check the letter case of the file spec in the -r: parameter. It's case-sensitive if IPD is not being used. 
   If you continue to have this message try specifying -s with a number larger than 2097152. Alternately, 
   specify the following: -ipd -matemode:none -matedonly This causes the tool to use an IPD manifest, 
   but not actually use IPD. A warning will be generated if you do this, but can be safely ignored.

7. Credits
=================================
* Development: RAX Software
* Coded in AutoIt: AutoItScript.com
* Special thanks for a bugfix: Lexicon78
* A friend of the developer who prefers to remain anonymous: For helping with IPD code

* SFX Stub: Microsoft Corporation
* IPD Engine: Microsoft Corporation
